import 'package:flutter/cupertino.dart';

class Product {
  String name;
  int id;
  String image;
  double price;
  double offPercent;

  Product(
      {@required this.name,
      @required this.id,
      @required this.image,
      this.price,
      this.offPercent});
}
